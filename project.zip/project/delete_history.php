<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_id'])) {
    $form_id = $_POST['form_id'];

    // Delete the grades associated with the form
    $stmt = $conn->prepare("DELETE FROM grades WHERE form_id = ?");
    $stmt->bind_param("i", $form_id);
    if ($stmt->execute()) {
        // Delete the form entry itself
        $stmt = $conn->prepare("DELETE FROM forms WHERE id = ?");
        $stmt->bind_param("i", $form_id);
        if ($stmt->execute()) {
            // Redirect to the history page after deletion
            header("Location: history.php");
            exit();
        } else {
            echo "Error deleting the form.";
        }
    } else {
        echo "Error deleting the grades.";
    }
}
?>
