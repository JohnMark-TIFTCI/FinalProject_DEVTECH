<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];

// Fetch all forms submitted by the user
$sql = "SELECT * FROM forms WHERE username = '$username' ORDER BY created_at DESC";
$forms = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="design.css">
    <title>History</title>
</head>
<body>
<div class="button-box">
            <a href="dashboard.php" class="btn">Dashboard</a>
            <a href="grading_form.php" class="btn">Grading Form</a>
            <a href="logout.php" class="btn">Logout</a>
        </div>
    <h1>History of Submitted Grades</h1>

    <?php
    // Loop through each form and display the grades and final average
    while ($form = $forms->fetch_assoc()) {
        $form_id = $form['id'];
        $grades_data = [];
        
        // Fetch grades for this form
        $result = $conn->query("SELECT * FROM grades WHERE form_id = '$form_id'");
        $total_average = 0;
        $total_subjects = 0;
        
        echo "<h3>Form Submitted on: " . $form['created_at'] . "</h3>";

        // Add the name and section prompt above the grading history
        echo "<p><strong>Name:</strong> " . htmlspecialchars($form['name']) . "</p>";
        echo "<p><strong>Section:</strong> " . htmlspecialchars($form['section']) . "</p>";
        
        echo "<table border='1' cellpadding='10'>
                <tr>
                    <th>Subject</th>
                    <th>Prelim</th>
                    <th>Midterm</th>
                    <th>Finals</th>
                    <th>Average</th>
                </tr>";
        
        while ($row = $result->fetch_assoc()) {
            $total_average += $row['average'];
            $total_subjects++;
            echo "<tr>
                    <td>{$row['subject']}</td>
                    <td>{$row['prelim']}</td>
                    <td>{$row['midterm']}</td>
                    <td>{$row['finals']}</td>
                    <td>" . number_format($row['average'], 2) . "</td>
                  </tr>";
        }
        
        // Calculate final average
        $final_average = $total_subjects > 0 ? $total_average / $total_subjects : 0;
        echo "</table>";
        
        echo "<p><strong>Your Final Average:</strong> " . number_format($final_average, 2) . "</p>";
        echo "<form method='POST' action='delete_history.php'>
                <input type='hidden' name='form_id' value='$form_id'>
                <button type='submit' onclick='return confirm(\"Are you sure you want to delete this grading form?\");'>Delete Form</button>
              </form>";
    }
    ?>

    <br>
    <div class="button-container">
    <a href="dashboard.php" class="back-to-dashboard">Back to Dashboard</a>
</div>
</body>
</html>
