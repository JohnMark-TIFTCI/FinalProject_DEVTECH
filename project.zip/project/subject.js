let subjectCount = 1;

// Add a new subject row
function addSubject() {
    subjectCount++;
    const subjectRow = `
        <tr id="subject_row_${subjectCount}">
            <td><input type="text" name="grades[subject_${subjectCount}][subject]" placeholder="Enter Subject" required oninput="adjustInputLength(${subjectCount}); calculateAverage(${subjectCount})"></td>
            <td><input type="number" name="grades[subject_${subjectCount}][prelim]" min="0" max="100" required oninput="calculateAverage(${subjectCount})"></td>
            <td><input type="number" name="grades[subject_${subjectCount}][midterm]" min="0" max="100" required oninput="calculateAverage(${subjectCount})"></td>
            <td><input type="number" name="grades[subject_${subjectCount}][finals]" min="0" max="100" required oninput="calculateAverage(${subjectCount})"></td>
            <td><span id="subject_${subjectCount}_average"></span></td>
            <td><button type="button" onclick="removeSubject(${subjectCount})">Remove</button></td>
        </tr>
    `;
    $('#grading_table tbody').append(subjectRow);
}

// Remove a subject row
function removeSubject(id) {
    $(`#subject_row_${id}`).remove();
    updateOverallAverage();
}

// Calculate average for each subject
function calculateAverage(subjectId) {
    const prelim = parseFloat($(`[name="grades[subject_${subjectId}][prelim]"]`).val()) || 0;
    const midterm = parseFloat($(`[name="grades[subject_${subjectId}][midterm]"]`).val()) || 0;
    const finals = parseFloat($(`[name="grades[subject_${subjectId}][finals]"]`).val()) || 0;
    const average = (prelim + midterm + finals) / 3;
    $(`#subject_${subjectId}_average`).text(average.toFixed(2));

    updateOverallAverage();
}

// Update the overall average of all subjects
function updateOverallAverage() {
    let totalAverage = 0;
    let subjectCount = 0;

    // Loop through all subject rows to calculate the overall average
    $('[id^="subject_row_"]').each(function() {
        const subjectId = $(this).attr('id').split('_')[2];
        const average = parseFloat($(`#subject_${subjectId}_average`).text()) || 0;
        totalAverage += average;
        if (average > 0) subjectCount++;
    });

    // Update the overall average
    const overallAverage = subjectCount > 0 ? totalAverage / subjectCount : 0;
    $('#overall_average').text(overallAverage.toFixed(2));
}

// Adjust the input field size dynamically based on subject name length
function adjustInputLength(id) {
    const subjectInput = $(`[name="grades[subject_${id}][subject]"]`);
    const subjectLength = subjectInput.val().length;
    // Dynamically adjust the width of the input box
    subjectInput.css('width', (subjectLength + 5) + 'ch'); // Added +5 to give some space
}

// Apply dynamic resizing to all subject inputs when the page loads
$(document).ready(function() {
    $('input[name^="grades[subject_"]').each(function() {
        const subjectId = $(this).attr('name').match(/subject_(\d+)/)[1];
        adjustInputLength(subjectId);
    });
});

// Clear all grades and reset the overall average
function clearGrades() {
    let subjectRows = document.querySelectorAll('[id^="subject_row_"]'); // Select all subject rows
    subjectRows.forEach(function(row) {
        const subjectId = row.id.split('_')[2]; // Extract the subject id (1, 2, etc.)

        // Clear the values in the respective input fields for both predefined and dynamically added subjects
        const subjectInput = document.querySelector(`[name="grades[subject_${subjectId}][subject]"]`);
        const prelimInput = document.querySelector(`[name="grades[subject_${subjectId}][prelim]"]`);
        const midtermInput = document.querySelector(`[name="grades[subject_${subjectId}][midterm]"]`);
        const finalsInput = document.querySelector(`[name="grades[subject_${subjectId}][finals]"]`);

        if (subjectInput) subjectInput.value = '';  // Subject name
        if (prelimInput) prelimInput.value = '';  // Prelim grade
        if (midtermInput) midtermInput.value = '';  // Midterm grade
        if (finalsInput) finalsInput.value = '';  // Finals grade
        document.querySelector(`#subject_${subjectId}_average`).innerText = ''; // Clear average
    });

    // Reset the overall average
    document.getElementById('overall_average').innerText = '0.00';
}