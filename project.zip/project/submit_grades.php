<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_SESSION['username'];
    $grades = $_POST['grades'];

    // Initialize total average calculation
    $total_average = 0;
    $total_subjects = count($grades);

    // Insert form entry
    $stmt = $conn->prepare("INSERT INTO forms (username) VALUES (?)");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $form_id = $stmt->insert_id;

    // Insert grades and calculate average
    foreach ($grades as $subject => $scores) {
        $prelim = $scores['prelim'];
        $midterm = $scores['midterm'];
        $finals = $scores['finals'];
        $average = ($prelim + $midterm + $finals) / 3;

        $stmt = $conn->prepare("INSERT INTO grades (form_id, username, subject, prelim, midterm, finals, average) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issdddd", $form_id, $username, $subject, $prelim, $midterm, $finals, $average);
        $stmt->execute();

        $total_average += $average;
    }

    // Calculate final average
    $final_average = $total_subjects > 0 ? $total_average / $total_subjects : 0;

    // Return final average as a response to AJAX request
    echo number_format($final_average, 2);
}
?>
